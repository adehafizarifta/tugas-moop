
public class Kubus extends BangunRuang{
	private int sisi;
	@Override
	double luas() {
		double luas = 6 *sisi*sisi;
		System.out.println("Luas kubus adalah : "+ luas);
		return super.luas();
	}

	@Override
	double keliling() {
		double keliling = 12*sisi;
		System.out.println("Keliling kubus adalah : "+ keliling);
		return super.keliling();
	}

	@Override
	double volume() {
		double volume = sisi*sisi*sisi;
		System.out.println("Volume kubus adalah : "+ volume);
		return super.volume();
	}

	public int getSisi() {
		return sisi;
	}

	public void setSisi(int sisi) {
		this.sisi = sisi;
	}

	public Kubus(int sisi) {
		super();
		this.sisi = sisi;
	}
	
}
