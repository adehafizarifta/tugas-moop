
public class PersegiPanjang extends BangunDatar{
	private int lebar,panjang;

	@Override
	double luas() {
		double luas = panjang*lebar;
		System.out.println("Luas persegi panjang adalah : " + luas);
		return super.luas();
	}

	@Override
	double keliling() {
		double keliling = panjang*2 + lebar*2;
		System.out.println("Keliling persegi panjang adalah : " + keliling);
		return super.keliling();
	}

	public int getLebar() {
		return lebar;
	}

	public void setLebar(int lebar) {
		this.lebar = lebar;
	}

	public int getPanjang() {
		return panjang;
	}

	public void setPanjang(int panjang) {
		this.panjang = panjang;
	}

	public PersegiPanjang(int lebar, int panjang) {
		super();
		this.lebar = lebar;
		this.panjang = panjang;
	}
	
}
