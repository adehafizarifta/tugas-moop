
public class BangunDatar {
	double luas() {
		return 0;
	}
	
	double keliling() {
		return 0;
	}
}
